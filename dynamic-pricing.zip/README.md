# Dynamic Pricing System

This is a simple Python project that calculates product prices dynamically based on demand and stock.

## How it works

- If demand is high and stock is low → price increases.
- If demand is low and stock is high → price decreases.

## Example usage

```python
dynamic_price(100, "high", 10)  # Output: 150.0
```

## Run the script

```bash
python pricing.py
```
